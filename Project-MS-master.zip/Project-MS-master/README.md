# Django Project

Este es un proyecto web desarrollado con Django.

## Requisitos Previos

- Python 3.x
- pip (gestor de paquetes de Python)

## Instalación

Sigue los siguientes pasos para configurar y ejecutar este proyecto en tu entorno local.

### 1. Clonar el Repositorio

```bash
git clone https://github.com/tu_usuario/nombre_del_proyecto.git
cd nombre_del_proyecto
```

## 2. Crear y Activar un Entorno Virtual
```bash
cd server
python -m venv venv
venv\Scripts\activate
```
##  3. Instalar Dependencias
Instala las dependencias necesarias desde el archivo requirements.txt.

```bash
pip install -r requirements.txt
```
## 4. Configurar el Proyecto
Asegúrate de que el archivo settings.py tenga las configuraciones correctas para tu base de datos y otros ajustes locales.

## 5. Realizar Migraciones
Aplica las migraciones necesarias para configurar la base de datos(Hacer esto si quieres tener todas las actualizaciones en tu BD):

```bash
python manage.py migrate
```

## 6. Ejecutar la Aplicación
Inicia el servidor de desarrollo de Django:
```bash
python manage.py runserver 0.0.0.0:8000
```
Accede a la aplicación en tu navegador en http://<tu-ip>:8000

## Contribuciones
1. Crea una nueva rama para tu funcionalidad (git checkout -b feature/nueva-funcionalidad).
2. Realiza tus cambios y commitea (git commit -m 'Añadir nueva funcionalidad').
3. Haz push a la rama (git push origin feature/nueva-funcionalidad).
4. Abre un Pull Request.
