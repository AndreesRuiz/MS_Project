from django.db import models

# Create your models here.


class ordenes(models.Model):
    job = models.CharField(max_length=50)
    origin_date = models.DateField()
    customer = models.CharField(max_length=50)
    thickness_metal = models.FloatField()
    metal = models.CharField(max_length=50)
    thickness_rubber = models.FloatField()
    rubber = models.CharField(max_length=50)
    part_number = models.CharField(max_length=50)
    pieces = models.IntegerField()
    sheets_order = models.FloatField()
    due_date = models.DateField()
    month = models.IntegerField()
    yield_value = models.IntegerField()
    screw = models.CharField(max_length=50)


class scrap(models.Model):
    job = models.CharField(max_length=50)
    date = models.DateField()
    part_number = models.CharField(max_length=50)
    presentation = models.CharField(max_length=50)
    scrap2033 = models.IntegerField()
    shift = models.IntegerField()
    department = models.CharField(max_length=50)
    area = models.CharField(max_length=50)
    GA = models.IntegerField()
    metal = models.CharField(max_length=50)
    metal_provider = models.CharField(max_length=50)
    thickness_rubber = models.FloatField()
    rubber_type = models.CharField(max_length=50)
    guillotine = models.FloatField()
    total_sheets_lbs = models.FloatField()
