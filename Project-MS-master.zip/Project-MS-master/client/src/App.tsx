function App() {
    return <div className='text-3xl font-bold underline grid justify-center content-center h-screen'>hola</div>;
}

export default App;
